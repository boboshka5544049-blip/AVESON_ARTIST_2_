# AVESON ARTIST 2.0

Fresh Android project for the AVESON artist-facing app.

## Build

```bash
gradle :app:assembleDebug
```

GitHub Actions builds the APK with Java 17 and Gradle 8.9.

## Important

`gradle.properties` enables AndroidX and Jetifier so AndroidX dependencies can be resolved correctly in CI.
