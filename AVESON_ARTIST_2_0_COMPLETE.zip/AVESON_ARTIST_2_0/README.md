# AVESON ARTIST 2.0
Version 2.0.0 | versionCode 200 | applicationId com.aveson.artist

Artist-focused AVESON workspace: HOME, MUSIC, NEW RELEASE, ANALYTICS, MORE.
MORE includes Platforms, Video & Clips, Audio Standards, Cover Standards, Rights, Royalties, Distribution, Audience, Marketing, Profile & Settings, Legal & Documents, Languages and Support.

UI prototype; real authentication/backend/DSP integrations are separate production work.
